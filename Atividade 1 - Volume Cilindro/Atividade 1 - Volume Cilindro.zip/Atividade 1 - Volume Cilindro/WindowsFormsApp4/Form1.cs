﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)//Validar
        {
            double Raio;

            if (!Double.TryParse(textBox1.Text, out Raio))
                MessageBox.Show("Valor invalido");
            else if (Raio <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");// repitir na altura
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            double Altura;

            if (!Double.TryParse(textBox1.Text, out Altura))
                MessageBox.Show("Valor invalido");
            else if (Altura <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");// repitir nos outro texts
        }

        private void button1_Validated(object sender, EventArgs e)
        {
            double Raio;

            if (!Double.TryParse(textBox1.Text, out Raio))
            {
                MessageBox.Show("Raio inválido");
                textBox1.Focus();
            }
            else
            if (Raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero");
                textBox1.Focus();
            }

            else//outro componente
            {
                double Altura;

                if (!Double.TryParse(textBox2.Text, out Altura))
                {
                    MessageBox.Show("Altura inválida");
                    textBox2.Focus();
                }
                else
                if (Altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero");
                    textBox2.Focus();
                }

                else//outro componente
                {
                    // calculo
                    // volume = pi x raio x raio x altura
                    double Volume;
                    // volume = 3.14 * Raio * Raio * Altura;
                    //ou
                    Volume = Math.PI * Math.Pow(Raio, 2) * Altura;

                    textBox3.Text = Volume.ToString("N2");

                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
