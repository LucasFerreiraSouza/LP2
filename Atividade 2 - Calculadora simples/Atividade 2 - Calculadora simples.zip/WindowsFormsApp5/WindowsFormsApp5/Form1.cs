﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)// 1 VALIDAR
        {
            Double Num1;

            if (!Double.TryParse(textBox1.Text, out Num1))
                MessageBox.Show("Valor inválido!");//Sem focus aqui
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            Double Num2;

            if (!Double.TryParse(textBox2.Text, out Num2))
                MessageBox.Show("Valor inválido!");
        }

        private void button3_Validated(object sender, EventArgs e)//2 Validar com "+" (CLICK DO MOUSE NÂO FUNCIONA NESTE CASO, USE TAB E ENTER).
        {
            Double Num1;

            if (!Double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                textBox1.Focus();
            }

            else//Outro componente!Cuidado com a identação ATENÇÃO
            {
                Double Num2;//Outro componente!Declara de novo ATENÇÃO

                if (!Double.TryParse(textBox2.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    textBox2.Focus();
                }

                else//Se tudo deu certo faça...CALCULOS
                {
                    Double Soma;//Outro componente!Declara de novo ATENÇÃO
                    Soma = Num1 + Num2;
                    textBox3.Text = Soma.ToString("N2");//Enviando o resultado para o textBox3
                }
            }
        }

        private void button4_Validated(object sender, EventArgs e)//-
        {
            Double Num1;

            if (!Double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                textBox1.Focus();
            }

            else
            {
                Double Num2;

                if (!Double.TryParse(textBox2.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    textBox2.Focus(); // "enable=false" nele
                }

                else
                {
                    Double Subt;
                    Subt = Num1 - Num2;
                    textBox3.Text = Subt.ToString("N2");//Enviando o resultado para o textBox3
                }
            }
        }

        private void button5_Validated(object sender, EventArgs e)//*
        {
            Double Num1;

            if (!Double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                textBox1.Focus();
            }

            else
            {
                Double Num2;

                if (!Double.TryParse(textBox2.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    textBox2.Focus();
                }

                else
                {
                    Double Mult;
                    Mult = Num1 * Num2;
                    textBox3.Text = Mult.ToString("N2");//Enviando o resultado para o textBox3
                }
            }
        }

        private void button6_Validated(object sender, EventArgs e)// /
        {
            Double Num1;

            if (!Double.TryParse(textBox1.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                textBox1.Focus();
            }

            else
            {
                Double Num2;

                if (!Double.TryParse(textBox2.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    textBox2.Focus();
                }

                    else if (Num2 == 0)
                    {
                         MessageBox.Show("Valor inválido, Não existe divisão por zero!");//Com focus aqui
                         textBox2.Focus();
                    }

                else
                {
                    Double Div;
                    Div = Num1 / Num2;
                    textBox3.Text = Div.ToString("N2");//Enviando o resultado para o textBox3
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)//CLICK
        {
            textBox1.Text = "";//Vira nulo
            textBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
