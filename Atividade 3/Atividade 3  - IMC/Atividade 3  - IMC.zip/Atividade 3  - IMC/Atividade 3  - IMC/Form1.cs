﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_3____IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            Double Peso;

            if (!Double.TryParse(txtPeso.Text, out Peso))
                MessageBox.Show("Valor inválido!");//Sem focus 
            else if (Peso <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            Double Altura;

            if (!Double.TryParse(txtAltura.Text, out Altura))
                MessageBox.Show("Valor inválido!");//Sem focus 
            else if (Altura <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Double Peso;

            if (!Double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Valor inválido!");//Com focus 
                txtPeso.Focus();
            }
            else if (Peso <= 0)
            {
                MessageBox.Show("Valor tem que ser maior que zero");
                txtPeso.Focus();
            }

            else
            {
                Double Altura;

                if (!Double.TryParse(txtAltura.Text, out Altura))
                {
                    MessageBox.Show("Valor inválido!");//Com focus 
                    txtAltura.Focus();
                }
                else if (Altura <= 0)
                {
                    MessageBox.Show("Valor tem que ser maior que zero");
                    txtAltura.Focus();
                }

                else//Se tudo deu certo
                {
                    Double Imc;

                    Imc = Peso / (Altura * Altura);//Calculo
                    Imc = Math.Round(Imc,1);//Arredondar

                    txtImc.Text = Imc.ToString("N2");//Enviando o resultado

                    if (Imc <= 0)
                    {
                        MessageBox.Show("Use a vírgula e não o ponto!");
                        txtPeso.Focus();
                        txtAltura.Focus();
                    }
                    else if (Imc < 18.5)
                        MessageBox.Show("Classicação: Magreza e Obesidade: Grau 0");
                    else if (Imc >= 18.5 && Imc < 24.9)
                        MessageBox.Show("Classicação: Normal e Obesidade: Grau 0");
                    else if (Imc >= 25 && Imc < 29.9)
                        MessageBox.Show("Classicação: Sobrepeso e Obesidade: Grau I");
                    else if (Imc >= 30 && Imc < 39.9)
                        MessageBox.Show("Classicação: Obesidade e Obesidade: Grau II");
                    else if (Imc > 40)
                        MessageBox.Show("Classicação: Obesidade Grave e Obesidade: Grau III");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Text = "";
            txtAltura.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
