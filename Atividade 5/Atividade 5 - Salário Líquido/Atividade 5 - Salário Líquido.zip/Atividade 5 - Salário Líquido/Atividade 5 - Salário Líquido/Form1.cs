﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5___Salário_Líquido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNomeFunc_Validated(object sender, EventArgs e)
        {
            double dnomeFuncionario;

            if (Double.TryParse(txtNomeFunc.Text, out dnomeFuncionario))//Se não for string
                MessageBox.Show("Este nome de funcionário é inválido, digite o nome novamente!");
            else if (txtNomeFunc.Text == "")
                MessageBox.Show("Nome do funcionário está vazio, digite o nome novamente!");
        }

        private void mskbxSalBrut_Validated(object sender, EventArgs e)
        {
            double salBrut;

            if (!Double.TryParse(mskbxSalBrut.Text, out salBrut))
                MessageBox.Show("Valor invalido");
            else if (salBrut <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");
        }

        private void cbxNumFilh_Validated(object sender, EventArgs e)
        {
            double numFilh;

            if (!Double.TryParse(cbxNumFilh.Text, out numFilh))
                MessageBox.Show("Valor invalido");
        }

        private void btnVeriDesc_Click(object sender, EventArgs e)
        {
            double dnomeFuncionario;

            if (Double.TryParse(txtNomeFunc.Text, out dnomeFuncionario))//Se não for string
            {
                MessageBox.Show("Este nome de funcionário é inválido, digite o nome novamente!");
                txtNomeFunc.Focus();
            }
            else if (txtNomeFunc.Text == "")
            {
                MessageBox.Show("Nome do funcionário está vazio, digite o nome!");
                txtNomeFunc.Focus();
            }

            else//Outro componente
            {
                double salBrut;

                if (!Double.TryParse(mskbxSalBrut.Text, out salBrut))
                {
                    MessageBox.Show("Valor invalido");
                    mskbxSalBrut.Focus();
                }
                else if (salBrut <= 0)
                {
                    MessageBox.Show("Valor tem que ser maior que zero");
                    mskbxSalBrut.Focus();
                }

                else//Outro componente
                {
                    double numFilh;

                    if (!Double.TryParse(cbxNumFilh.Text, out numFilh))
                    {
                        MessageBox.Show("Valor invalido");
                        cbxNumFilh.Focus();
                    }

                    else//Se tudo de certo, faça o calculo
                    {
                        double descINSS;
                        double descIRPF;
                        double salFamil;
                        double salLiqui;

                        //Desconto do INSS
                        if (salBrut <= 800.47)
                        {
                            txtAliqINSS.Text = "7,65%";
                            descINSS = salBrut * 0.0765;
                        }
                        else if (salBrut >= 800.48 && salBrut <= 1050)
                        {
                            txtAliqINSS.Text = "8,65%";
                            descINSS = salBrut * 0.0865;
                        }
                        else if (salBrut >= 1050.01 && salBrut <= 1400.77)//INSS
                        {
                            txtAliqINSS.Text = "9,00%";
                            descINSS = salBrut * 0.0900;
                        }
                        else if (salBrut >= 1400.78 && salBrut <= 2801.56)
                        {
                            txtAliqINSS.Text = "11,00%";
                            descINSS = salBrut * 0.1100;
                        }
                        else //INSS Teto
                        {
                            txtAliqINSS.Text = "Teto";
                            descINSS = 308.17;
                        }

                        //Desconto do IRPF
                        if (salBrut <= 1257.12)
                        {
                            txtAliqIRPF.Text = "Isento";
                            descIRPF = salBrut * 0;
                        }
                        else if (salBrut >= 1257.13 && salBrut <= 2512.08)
                        {
                            txtAliqIRPF.Text = "15,00%";
                            descIRPF = salBrut * 0.1500;
                        }
                        else //IRPF máximo
                        {
                            txtAliqIRPF.Text = "27,50%";
                            descIRPF = salBrut * 0.2750;
                        }

                        //Salário família
                        if (salBrut <= 435.52)
                        {
                            salFamil = numFilh * 22.33;
                        }
                        else if (salBrut >= 435.53 && salBrut <= 654.61)
                        {
                            salFamil = numFilh * 15.74;
                        }
                        else
                        {
                            salFamil = numFilh * 0;//Não ganha mais o salário família
                        }

                        //CÁLCULO DO SALÁRIO LÍQUIDO
                        salLiqui = salBrut - descINSS - descIRPF + salFamil;

                        txtDescINSS.Text = descINSS.ToString("N2");
                        txtDescIRPF.Text = descIRPF.ToString("N2");
                        txtSalFami.Text = salFamil.ToString("N2");
                        txtSalLiqui.Text = salLiqui.ToString("N2");

                        //Dados
                        string sdoDa;
                        string ssrSra;
                        string snomFunc;
                        string ssoltCasad;
                        string snumFilh;

                        if (rbtnFemini.Checked == true)//sdoDa
                            sdoDa = "da";
                        else
                            sdoDa = "do";

                        if (rbtnFemini.Checked == true)//ssrSra
                            ssrSra = "Sra.";
                        else
                            ssrSra = "Sr.";

                        if (txtNomeFunc.Text != "")//snomFunc
                            snomFunc = txtNomeFunc.Text;
                        else
                            snomFunc = "Erro!";

                        if (rbtnFemini.Checked == true && ckbxCasado.Checked == true)//ssoltCasad
                            ssoltCasad = "casada";
                        else if (rbtnFemini.Checked == true && ckbxCasado.Checked == false)
                            ssoltCasad = "solteira";
                        else if (rbtnMascu.Checked == true && ckbxCasado.Checked == true)
                            ssoltCasad = "casado";
                        else
                            ssoltCasad = "solteiro";

                        snumFilh = "-1";//snumFilh

                        if (cbxNumFilh.SelectedItem != "0")
                            snumFilh = "tem " + cbxNumFilh.SelectedItem + " filho(s)";
                        else if (cbxNumFilh.SelectedItem == "0")
                            snumFilh = "não tem filho(a)";

                        //lblDados.Text = "Os descontos do salário do(a) Sr(a) Lucas Ferreira de Souza que é solteiro(a) e que tem 2 filho(s) são:"

                        lblDados.Text = "Os descontos do salário" + " " + sdoDa + " " + ssrSra + " " + snomFunc + " " + "que é" + " " + ssoltCasad + " " + "e que" + " " + snumFilh + " " + "é: ";
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxNumFilh.SelectedItem  = "0";
        }
    }
}
