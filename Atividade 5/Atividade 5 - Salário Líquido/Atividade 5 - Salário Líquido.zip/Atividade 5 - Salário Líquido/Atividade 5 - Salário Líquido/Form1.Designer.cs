﻿namespace Atividade_5___Salário_Líquido
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalBrut = new System.Windows.Forms.Label();
            this.lblNumFilh = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.lblSalFami = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.mskbxSalBrut = new System.Windows.Forms.MaskedTextBox();
            this.cbxNumFilh = new System.Windows.Forms.ComboBox();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFami = new System.Windows.Forms.TextBox();
            this.txtSalLiqui = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnFemini = new System.Windows.Forms.RadioButton();
            this.rbtnMascu = new System.Windows.Forms.RadioButton();
            this.pnlEstadoCivil = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.btnVeriDesc = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.gbxSexo.SuspendLayout();
            this.pnlEstadoCivil.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(37, 9);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(90, 13);
            this.lblNomeFunc.TabIndex = 1;
            this.lblNomeFunc.Text = "Nome funcionário";
            // 
            // lblSalBrut
            // 
            this.lblSalBrut.AutoSize = true;
            this.lblSalBrut.Location = new System.Drawing.Point(37, 39);
            this.lblSalBrut.Name = "lblSalBrut";
            this.lblSalBrut.Size = new System.Drawing.Size(66, 13);
            this.lblSalBrut.TabIndex = 3;
            this.lblSalBrut.Text = "Salário bruto";
            // 
            // lblNumFilh
            // 
            this.lblNumFilh.AutoSize = true;
            this.lblNumFilh.Location = new System.Drawing.Point(37, 66);
            this.lblNumFilh.Name = "lblNumFilh";
            this.lblNumFilh.Size = new System.Drawing.Size(92, 13);
            this.lblNumFilh.TabIndex = 5;
            this.lblNumFilh.Text = "Número de filho(s)";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Location = new System.Drawing.Point(37, 216);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(75, 13);
            this.lblAliqINSS.TabIndex = 14;
            this.lblAliqINSS.Text = "Alíquata INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Location = new System.Drawing.Point(37, 251);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(74, 13);
            this.lblAliqIRPF.TabIndex = 16;
            this.lblAliqIRPF.Text = "Alíquata IRPF";
            // 
            // lblSalFami
            // 
            this.lblSalFami.AutoSize = true;
            this.lblSalFami.Location = new System.Drawing.Point(37, 279);
            this.lblSalFami.Name = "lblSalFami";
            this.lblSalFami.Size = new System.Drawing.Size(73, 13);
            this.lblSalFami.TabIndex = 18;
            this.lblSalFami.Text = "Salário família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Location = new System.Drawing.Point(37, 306);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(74, 13);
            this.lblSalLiq.TabIndex = 20;
            this.lblSalLiq.Text = "Salário líquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(272, 220);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(81, 13);
            this.lblDescINSS.TabIndex = 22;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(272, 251);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(80, 13);
            this.lblDescIRPF.TabIndex = 24;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(146, 6);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(145, 20);
            this.txtNomeFunc.TabIndex = 2;
            this.txtNomeFunc.Validated += new System.EventHandler(this.txtNomeFunc_Validated);
            // 
            // mskbxSalBrut
            // 
            this.mskbxSalBrut.Location = new System.Drawing.Point(146, 32);
            this.mskbxSalBrut.Mask = "99990.00";
            this.mskbxSalBrut.Name = "mskbxSalBrut";
            this.mskbxSalBrut.Size = new System.Drawing.Size(145, 20);
            this.mskbxSalBrut.TabIndex = 4;
            this.mskbxSalBrut.Validated += new System.EventHandler(this.mskbxSalBrut_Validated);
            // 
            // cbxNumFilh
            // 
            this.cbxNumFilh.FormattingEnabled = true;
            this.cbxNumFilh.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.cbxNumFilh.Location = new System.Drawing.Point(146, 61);
            this.cbxNumFilh.Name = "cbxNumFilh";
            this.cbxNumFilh.Size = new System.Drawing.Size(145, 21);
            this.cbxNumFilh.TabIndex = 6;
            this.cbxNumFilh.Validated += new System.EventHandler(this.cbxNumFilh_Validated);
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Location = new System.Drawing.Point(146, 213);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(121, 20);
            this.txtAliqINSS.TabIndex = 15;
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Location = new System.Drawing.Point(146, 244);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(120, 20);
            this.txtAliqIRPF.TabIndex = 17;
            // 
            // txtSalFami
            // 
            this.txtSalFami.Enabled = false;
            this.txtSalFami.Location = new System.Drawing.Point(146, 279);
            this.txtSalFami.Name = "txtSalFami";
            this.txtSalFami.Size = new System.Drawing.Size(120, 20);
            this.txtSalFami.TabIndex = 19;
            // 
            // txtSalLiqui
            // 
            this.txtSalLiqui.BackColor = System.Drawing.SystemColors.Info;
            this.txtSalLiqui.Enabled = false;
            this.txtSalLiqui.Location = new System.Drawing.Point(146, 306);
            this.txtSalLiqui.Name = "txtSalLiqui";
            this.txtSalLiqui.Size = new System.Drawing.Size(120, 20);
            this.txtSalLiqui.TabIndex = 21;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(372, 213);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(127, 20);
            this.txtDescINSS.TabIndex = 23;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(372, 248);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(127, 20);
            this.txtDescIRPF.TabIndex = 25;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnFemini);
            this.gbxSexo.Controls.Add(this.rbtnMascu);
            this.gbxSexo.Location = new System.Drawing.Point(327, 6);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(200, 71);
            this.gbxSexo.TabIndex = 7;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbtnFemini
            // 
            this.rbtnFemini.AutoSize = true;
            this.rbtnFemini.Checked = true;
            this.rbtnFemini.Location = new System.Drawing.Point(17, 19);
            this.rbtnFemini.Name = "rbtnFemini";
            this.rbtnFemini.Size = new System.Drawing.Size(67, 17);
            this.rbtnFemini.TabIndex = 8;
            this.rbtnFemini.TabStop = true;
            this.rbtnFemini.Text = "Feminino";
            this.rbtnFemini.UseVisualStyleBackColor = true;
            // 
            // rbtnMascu
            // 
            this.rbtnMascu.AutoSize = true;
            this.rbtnMascu.Location = new System.Drawing.Point(17, 42);
            this.rbtnMascu.Name = "rbtnMascu";
            this.rbtnMascu.Size = new System.Drawing.Size(73, 17);
            this.rbtnMascu.TabIndex = 9;
            this.rbtnMascu.Text = "Masculino";
            this.rbtnMascu.UseVisualStyleBackColor = true;
            // 
            // pnlEstadoCivil
            // 
            this.pnlEstadoCivil.Controls.Add(this.ckbxCasado);
            this.pnlEstadoCivil.Location = new System.Drawing.Point(327, 83);
            this.pnlEstadoCivil.Name = "pnlEstadoCivil";
            this.pnlEstadoCivil.Size = new System.Drawing.Size(200, 26);
            this.pnlEstadoCivil.TabIndex = 10;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Checked = true;
            this.ckbxCasado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbxCasado.Location = new System.Drawing.Point(17, 3);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(74, 17);
            this.ckbxCasado.TabIndex = 11;
            this.ckbxCasado.Text = "Casado(a)";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // btnVeriDesc
            // 
            this.btnVeriDesc.Location = new System.Drawing.Point(232, 122);
            this.btnVeriDesc.Name = "btnVeriDesc";
            this.btnVeriDesc.Size = new System.Drawing.Size(121, 23);
            this.btnVeriDesc.TabIndex = 12;
            this.btnVeriDesc.Text = "Verificar desconto";
            this.btnVeriDesc.UseVisualStyleBackColor = true;
            this.btnVeriDesc.Click += new System.EventHandler(this.btnVeriDesc_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.SystemColors.Info;
            this.lblDados.Location = new System.Drawing.Point(37, 158);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(48, 13);
            this.lblDados.TabIndex = 13;
            this.lblDados.Text = "lblDados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.btnVeriDesc);
            this.Controls.Add(this.pnlEstadoCivil);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiqui);
            this.Controls.Add(this.txtSalFami);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.cbxNumFilh);
            this.Controls.Add(this.mskbxSalBrut);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFami);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblNumFilh);
            this.Controls.Add(this.lblSalBrut);
            this.Controls.Add(this.lblNomeFunc);
            this.Name = "Form1";
            this.Text = "Salário Líquido";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.pnlEstadoCivil.ResumeLayout(false);
            this.pnlEstadoCivil.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalBrut;
        private System.Windows.Forms.Label lblNumFilh;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.Label lblSalFami;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.MaskedTextBox mskbxSalBrut;
        private System.Windows.Forms.ComboBox cbxNumFilh;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.TextBox txtSalFami;
        private System.Windows.Forms.TextBox txtSalLiqui;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.Panel pnlEstadoCivil;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Button btnVeriDesc;
        private System.Windows.Forms.RadioButton rbtnMascu;
        private System.Windows.Forms.RadioButton rbtnFemini;
        private System.Windows.Forms.Label lblDados;
    }
}

