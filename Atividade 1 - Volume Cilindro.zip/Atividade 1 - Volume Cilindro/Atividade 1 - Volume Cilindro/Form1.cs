﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_1___Volume_Cilindro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double Raio;

            if (!Double.TryParse(txtRaio.Text, out Raio))
                MessageBox.Show("Valor invalido");
            else if (Raio <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");// repitir na altura
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double Altura;

            if (!Double.TryParse(txtAltura.Text, out Altura))
                MessageBox.Show("Valor invalido");
            else if (Altura <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");// repitir nos outro texts
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double Raio;

            if (!Double.TryParse(txtRaio.Text, out Raio))
            {
                MessageBox.Show("Raio inválido");
                txtRaio.Focus();
            }
            else
            if (Raio <= 0)
            {
                MessageBox.Show("Raio deve ser maior que zero");
                txtRaio.Focus();
            }

            else//outro componente
            {
                double Altura;

            if (!Double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Altura inválida");
                txtAltura.Focus();
            }
            else
            if (Altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero");
                txtAltura.Focus();
            }

            else//outro componente
            {
                // calculo
                // volume = pi x (raio x raio) x altura
                double Volume;

                Volume = Math.PI * Math.Pow(Raio, 2) * Altura;

                txtVolume.Text = Volume.ToString("N2");

            }
        }
    }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
