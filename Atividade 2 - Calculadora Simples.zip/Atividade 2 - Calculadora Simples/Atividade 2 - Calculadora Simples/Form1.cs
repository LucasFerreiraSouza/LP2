﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_2___Calculadora_Simples
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPrimeNum_Validated(object sender, EventArgs e)
        {
            Double Num1;

            if (!Double.TryParse(txtPrimeNum.Text, out Num1))
                MessageBox.Show("Valor inválido!");//Sem focus aqui
        }

        private void txtSegunNum_Validated(object sender, EventArgs e)
        {
            Double Num2;

            if (!Double.TryParse(txtSegunNum.Text, out Num2))
                MessageBox.Show("Valor inválido!");
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            Double Num1;

            if (!Double.TryParse(txtPrimeNum.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                txtPrimeNum.Focus();
            }

            else//Outro componente!Cuidado com a identação ATENÇÃO
            {
                Double Num2;//Outro componente!Declara de novo ATENÇÃO

                if (!Double.TryParse(txtSegunNum.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    txtSegunNum.Focus();
                }

                else//Se tudo deu certo faça...CALCULOS
                {
                    Double Soma;//Outro componente!Declara de novo ATENÇÃO
                    Soma = Num1 + Num2;
                    txtResultado.Text = Soma.ToString("N2");//Enviando o resultado para o textBox3
                }
            }

        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            Double Num1;

            if (!Double.TryParse(txtPrimeNum.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                txtPrimeNum.Focus();
            }

            else
            {
                Double Num2;

                if (!Double.TryParse(txtSegunNum.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    txtSegunNum.Focus(); // "enable=false" nele
                }

                else
                {
                    Double Subt;
                    Subt = Num1 - Num2;
                    txtResultado.Text = Subt.ToString("N2");//Enviando o resultado para o textBox3
                }
            }

        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            Double Num1;

            if (!Double.TryParse(txtPrimeNum.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                txtPrimeNum.Focus();
            }

            else
            {
                Double Num2;

                if (!Double.TryParse(txtSegunNum.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    txtSegunNum.Focus();
                }

                else
                {
                    Double Mult;
                    Mult = Num1 * Num2;
                    txtResultado.Text = Mult.ToString("N2");//Enviando o resultado para o textBox3
                }
            }

        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            Double Num1;

            if (!Double.TryParse(txtPrimeNum.Text, out Num1))
            {
                MessageBox.Show("Valor inválido!");//Com focus aqui
                txtPrimeNum.Focus();
            }

            else
            {
                Double Num2;

                if (!Double.TryParse(txtSegunNum.Text, out Num2))
                {
                    MessageBox.Show("Valor inválido!");//Com focus aqui
                    txtSegunNum.Focus();
                }

                else if (Num2 == 0)//NÂO EXISTE DIVISÂO POR ZERO
                {
                    MessageBox.Show("Valor inválido, Não existe divisão por zero!");//Com focus aqui
                    txtSegunNum.Focus();
                }

                else
                {
                    Double Div;
                    Div = Num1 / Num2;
                    txtResultado.Text = Div.ToString("N2");//Enviando o resultado para o textBox3
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPrimeNum.Text = "";//Vira nulo
            txtSegunNum.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
