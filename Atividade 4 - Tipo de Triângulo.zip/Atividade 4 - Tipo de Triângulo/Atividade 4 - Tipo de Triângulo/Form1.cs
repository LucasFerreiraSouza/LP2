﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4___Tipo_de_Triângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPrimeLado_Validated(object sender, EventArgs e)
        {
            double PrimeLado;

            if (!Double.TryParse(txtPrimeLado.Text, out PrimeLado))
                MessageBox.Show("Valor invalido");
            else if (PrimeLado <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");
        }

        private void txtSegunLado_Validated(object sender, EventArgs e)
        {
            double SegunLado;

            if (!Double.TryParse(txtSegunLado.Text, out SegunLado))
                MessageBox.Show("Valor invalido");
            else if (SegunLado <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");
        }

        private void txtTerceiLado_Validated(object sender, EventArgs e)
        {
            double TerceiLado;

            if (!Double.TryParse(txtTerceiLado.Text, out TerceiLado))
                MessageBox.Show("Valor invalido");
            else if (TerceiLado <= 0)
                MessageBox.Show("Valor tem que ser maior que zero");
        }

        private void btnClassificar_Click(object sender, EventArgs e)
        {
            double PrimeLado;

            if (!Double.TryParse(txtPrimeLado.Text, out PrimeLado))
            {
                MessageBox.Show("Valor invalido");
                txtPrimeLado.Focus();
            }
            else if (PrimeLado <= 0)
            {
                MessageBox.Show("Valor tem que ser maior que zero");
                txtPrimeLado.Focus();
            }

            else//Outro componente
            {
                double SegunLado;

                if (!Double.TryParse(txtSegunLado.Text, out SegunLado))
                {
                    MessageBox.Show("Valor invalido");
                    txtSegunLado.Focus();
                }
                else if (SegunLado <= 0)
                {
                    MessageBox.Show("Valor tem que ser maior que zero");
                    txtSegunLado.Focus();
                }


                else//Outro componente
                {
                    double TerceiLado;

                    if (!Double.TryParse(txtTerceiLado.Text, out TerceiLado))
                    {
                        MessageBox.Show("Valor invalido");
                        txtTerceiLado.Focus();
                    }
                    else if (TerceiLado <= 0)
                    {
                        MessageBox.Show("Valor tem que ser maior que zero");
                        txtTerceiLado.Focus();
                    }

                    else//Se tudo está certo
                    {

                        if ((PrimeLado+SegunLado)>TerceiLado && (TerceiLado + PrimeLado) > SegunLado && (SegunLado + TerceiLado) > PrimeLado)// Se for um triângulo faça
                        {
                            MessageBox.Show("Esse valores formam um triângulo");

                            if ((PrimeLado == SegunLado) && (PrimeLado == TerceiLado) && (SegunLado == TerceiLado))
                                MessageBox.Show("E formam um triângulo equilátero");

                            if ((PrimeLado == SegunLado && PrimeLado != TerceiLado && SegunLado != TerceiLado) || (PrimeLado == TerceiLado && PrimeLado !=SegunLado && TerceiLado != SegunLado) || (SegunLado == TerceiLado && SegunLado != PrimeLado && TerceiLado != PrimeLado))
                                MessageBox.Show("E formam um triângulo isóceles");

                            if ((PrimeLado != SegunLado) &&  (PrimeLado != TerceiLado) && (SegunLado != TerceiLado))
                                MessageBox.Show("E formam um triângulo escaleno");
                        }

                        else// Se  não for um triângulo faça
                        {
                            MessageBox.Show("Esse valores não formam um triângulo");
                            txtPrimeLado.Focus();
                            txtSegunLado.Focus();
                            txtTerceiLado.Focus();
                        }
                    }
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPrimeLado.Text = "";
            txtSegunLado.Text = "";
            txtTerceiLado.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
