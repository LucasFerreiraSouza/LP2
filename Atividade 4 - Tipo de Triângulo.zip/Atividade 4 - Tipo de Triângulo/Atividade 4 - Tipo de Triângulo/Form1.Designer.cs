﻿namespace Atividade_4___Tipo_de_Triângulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPrimeLado = new System.Windows.Forms.Label();
            this.txtPrimeLado = new System.Windows.Forms.TextBox();
            this.btnClassificar = new System.Windows.Forms.Button();
            this.lblSegunLado = new System.Windows.Forms.Label();
            this.txtSegunLado = new System.Windows.Forms.TextBox();
            this.lblTerceiLado = new System.Windows.Forms.Label();
            this.txtTerceiLado = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPrimeLado
            // 
            this.lblPrimeLado.AutoSize = true;
            this.lblPrimeLado.Location = new System.Drawing.Point(218, 56);
            this.lblPrimeLado.Name = "lblPrimeLado";
            this.lblPrimeLado.Size = new System.Drawing.Size(67, 13);
            this.lblPrimeLado.TabIndex = 1;
            this.lblPrimeLado.Text = "Primeiro lado";
            // 
            // txtPrimeLado
            // 
            this.txtPrimeLado.Location = new System.Drawing.Point(349, 53);
            this.txtPrimeLado.Name = "txtPrimeLado";
            this.txtPrimeLado.Size = new System.Drawing.Size(100, 20);
            this.txtPrimeLado.TabIndex = 2;
            this.txtPrimeLado.Validated += new System.EventHandler(this.txtPrimeLado_Validated);
            // 
            // btnClassificar
            // 
            this.btnClassificar.Location = new System.Drawing.Point(210, 228);
            this.btnClassificar.Name = "btnClassificar";
            this.btnClassificar.Size = new System.Drawing.Size(75, 23);
            this.btnClassificar.TabIndex = 7;
            this.btnClassificar.Text = "Classificar";
            this.btnClassificar.UseVisualStyleBackColor = true;
            this.btnClassificar.Click += new System.EventHandler(this.btnClassificar_Click);
            // 
            // lblSegunLado
            // 
            this.lblSegunLado.AutoSize = true;
            this.lblSegunLado.Location = new System.Drawing.Point(218, 107);
            this.lblSegunLado.Name = "lblSegunLado";
            this.lblSegunLado.Size = new System.Drawing.Size(73, 13);
            this.lblSegunLado.TabIndex = 3;
            this.lblSegunLado.Text = "Segundo lado";
            // 
            // txtSegunLado
            // 
            this.txtSegunLado.Location = new System.Drawing.Point(349, 100);
            this.txtSegunLado.Name = "txtSegunLado";
            this.txtSegunLado.Size = new System.Drawing.Size(100, 20);
            this.txtSegunLado.TabIndex = 4;
            this.txtSegunLado.Validated += new System.EventHandler(this.txtSegunLado_Validated);
            // 
            // lblTerceiLado
            // 
            this.lblTerceiLado.AutoSize = true;
            this.lblTerceiLado.Location = new System.Drawing.Point(218, 157);
            this.lblTerceiLado.Name = "lblTerceiLado";
            this.lblTerceiLado.Size = new System.Drawing.Size(69, 13);
            this.lblTerceiLado.TabIndex = 5;
            this.lblTerceiLado.Text = "Terceiro lado";
            // 
            // txtTerceiLado
            // 
            this.txtTerceiLado.Location = new System.Drawing.Point(349, 150);
            this.txtTerceiLado.Name = "txtTerceiLado";
            this.txtTerceiLado.Size = new System.Drawing.Size(100, 20);
            this.txtTerceiLado.TabIndex = 6;
            this.txtTerceiLado.Validated += new System.EventHandler(this.txtTerceiLado_Validated);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(608, 53);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Location = new System.Drawing.Point(608, 100);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(75, 23);
            this.btnFechar.TabIndex = 9;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtTerceiLado);
            this.Controls.Add(this.lblTerceiLado);
            this.Controls.Add(this.txtSegunLado);
            this.Controls.Add(this.lblSegunLado);
            this.Controls.Add(this.btnClassificar);
            this.Controls.Add(this.txtPrimeLado);
            this.Controls.Add(this.lblPrimeLado);
            this.Name = "Form1";
            this.Text = "Tipo de Triângulo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPrimeLado;
        private System.Windows.Forms.TextBox txtPrimeLado;
        private System.Windows.Forms.Button btnClassificar;
        private System.Windows.Forms.Label lblSegunLado;
        private System.Windows.Forms.TextBox txtSegunLado;
        private System.Windows.Forms.Label lblTerceiLado;
        private System.Windows.Forms.TextBox txtTerceiLado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnFechar;
    }
}

