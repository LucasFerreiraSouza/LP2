﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade7
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnQtdeCarNum_Click(object sender, EventArgs e)
        {
            int i;
            int qtdeCarNum;
            string mensagem;
            char posicao;

            qtdeCarNum = 0;

            for (i=0; i < rchtxtFrase.Text.Length; i++)
            {
                posicao = rchtxtFrase.Text[i];
                if (Char.IsNumber(posicao))
                    qtdeCarNum = qtdeCarNum + 1;
            }
            mensagem = qtdeCarNum.ToString();
            MessageBox.Show(mensagem);
        }

        private void btnPriCaracPosi_Click(object sender, EventArgs e)
        {
            int i;
            int posicaoEmBranco;
            string mensagem;
            string mensagemNegativa;
            char posicao;

            i = 0;
            posicaoEmBranco = 0;
            mensagemNegativa = "Não há espaços em branco";

            while (i < rchtxtFrase.Text.Length)
            {
                posicao = rchtxtFrase.Text[i];

                if (Char.IsWhiteSpace(posicao))
                {
                    posicaoEmBranco = i + 1;
                    mensagem = posicaoEmBranco.ToString();
                    MessageBox.Show(mensagem);
                    break;
                }
                else
                    i++;
            }
            if (i >= rchtxtFrase.Text.Length)
                MessageBox.Show(mensagemNegativa);
        }

        private void btnQtdeCarAlfa_Click(object sender, EventArgs e)
        {
            int qtdeCarAlfa;
            string mensagem;

            qtdeCarAlfa = 0;

            foreach(Char posicao in rchtxtFrase.Text)
            {
                if (Char.IsLetter(posicao))
                    qtdeCarAlfa = qtdeCarAlfa + 1;
            }
            mensagem = qtdeCarAlfa.ToString();
            MessageBox.Show(mensagem);
        }
    }
}
