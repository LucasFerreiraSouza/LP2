﻿namespace Atividade7
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdeCarNum = new System.Windows.Forms.Button();
            this.btnPriCaracPosi = new System.Windows.Forms.Button();
            this.btnQtdeCarAlfa = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdeCarNum
            // 
            this.btnQtdeCarNum.Location = new System.Drawing.Point(182, 174);
            this.btnQtdeCarNum.Name = "btnQtdeCarNum";
            this.btnQtdeCarNum.Size = new System.Drawing.Size(75, 81);
            this.btnQtdeCarNum.TabIndex = 2;
            this.btnQtdeCarNum.Text = "Quantidade de caracteres numéricos";
            this.btnQtdeCarNum.UseVisualStyleBackColor = true;
            this.btnQtdeCarNum.Click += new System.EventHandler(this.btnQtdeCarNum_Click);
            // 
            // btnPriCaracPosi
            // 
            this.btnPriCaracPosi.Location = new System.Drawing.Point(309, 173);
            this.btnPriCaracPosi.Name = "btnPriCaracPosi";
            this.btnPriCaracPosi.Size = new System.Drawing.Size(75, 82);
            this.btnPriCaracPosi.TabIndex = 3;
            this.btnPriCaracPosi.Text = "Primeiro caracter em branco e sua posicão";
            this.btnPriCaracPosi.UseVisualStyleBackColor = true;
            this.btnPriCaracPosi.Click += new System.EventHandler(this.btnPriCaracPosi_Click);
            // 
            // btnQtdeCarAlfa
            // 
            this.btnQtdeCarAlfa.Location = new System.Drawing.Point(443, 172);
            this.btnQtdeCarAlfa.Name = "btnQtdeCarAlfa";
            this.btnQtdeCarAlfa.Size = new System.Drawing.Size(75, 83);
            this.btnQtdeCarAlfa.TabIndex = 4;
            this.btnQtdeCarAlfa.Text = "Quantidade de caracteres alfabéticos";
            this.btnQtdeCarAlfa.UseVisualStyleBackColor = true;
            this.btnQtdeCarAlfa.Click += new System.EventHandler(this.btnQtdeCarAlfa_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(182, 48);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(336, 96);
            this.rchtxtFrase.TabIndex = 1;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnQtdeCarAlfa);
            this.Controls.Add(this.btnPriCaracPosi);
            this.Controls.Add(this.btnQtdeCarNum);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnQtdeCarNum;
        private System.Windows.Forms.Button btnPriCaracPosi;
        private System.Windows.Forms.Button btnQtdeCarAlfa;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}